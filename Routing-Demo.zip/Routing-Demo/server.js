const express=require("express");
const bodyParser=require("body-parser");
const cookieParser=require("cookie-parser");
const session=require("express-session");
var Path=require("path");
const commonRoutes=require("./routes/commonroute");
const productRoutes=require("./routes/product-routes");
var app=express();
//set the view engine
app.set("views","views");
app.set("view engine","pug");
//configure middleware
app.use(express.static(Path.resolve(__dirname,"public")));
app.use(cookieParser("mysecretkey"));
app.use(session({name:"session",resave:true,saveUninitialized:false,
secret:"mysecretsessionkey"}))
//config routes
app.use("/",commonRoutes);
app.use("/products",productRoutes);
module.exports=app;