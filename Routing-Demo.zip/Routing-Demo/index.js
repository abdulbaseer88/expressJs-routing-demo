var http=require("http");
//var {requestHandler}=require("./request-handler") //importing request-handler
const app=require("./server");

var server=http.createServer(app);
server.listen(3241,(err)=>{
    if(err){
        console.log("server coudn't start");
        return;
    }
    console.log("server started in port 3241");
})
