const express = require("express");
var router = express.Router();
var products = [{ id: 1, name: "apple", quantity: 10, price: 120 },
 { id: 2, name: "santra", quantity: 10, price: 120 },
  { id: 3, name: "kheera", quantity: 10, price: 120 },
   { id: 4, name: "jamun", quantity: 10, price: 120 }];


router.get("/list", (req, res) => {

    var model={
        caption:"Product List",
        items:products
    };
    res.header("Content-Type", "text/html")
        .render("product-list",model);
});
router.get("/add", (req, res) => {
    res.header("Content-Type", "text/html")
        .send("Product add form");
});
module.exports = router;