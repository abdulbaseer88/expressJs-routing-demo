const express = require("express");

var router = express.Router();

//GET/
router.get("/", (req, res) => {
    res.header("Content-Type", "text/html")
        .render("index");
});

//GET/about
router.get("/about", (req, res) => {
    res.header("Content-Type", "text/html")
        .render("about");
});

//GET/contact
router.get("/contact", (req, res) => {
    res.header("Content-Type", "text/html")
        .render("contact");
});

//get/contact
router.get("/register", (req, res) => {
    res.header("Content-Type", "text/html")
        .render("register");
});

module.exports=router;